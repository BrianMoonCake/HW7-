use std::f64::consts::PI;

trait CanonicalP {
    fn create(num_sides: u32, side_length: f64) -> Self;
    fn radius(&self) -> f64;
    fn area(&self) -> f64;
    fn perimeter(&self) -> f64;
}

struct CanonicalPolygon {
    num_sides: u32,
    side_length: f64,
}

impl CanonicalP for CanonicalPolygon {
    fn create(num_sides: u32, side_length: f64) -> Self {
        CanonicalPolygon {
            num_sides,
            side_length,
        }
    }

    fn perimeter(&self) -> f64 {
        self.num_sides as f64 * self.side_length
    }

    fn area(&self) -> f64 {
        let perimeter = self.perimeter();
        let apothem = self.radius();
        (perimeter * apothem) / 2.0
    }

    fn radius(&self) -> f64 {
        self.side_length / (2.0 * (PI / self.num_sides as f64).sin())
    }
}

fn main() {
    let sides = vec![6, 12, 24, 128, 256, 512, 1024, 2048, 65536];
    let lengths = vec![5.0, 6.5, 14.3];

    for &num_sides in &sides {
        for &side_length in &lengths {
            let polygon = CanonicalPolygon::create(num_sides, side_length);
            let circle_radius = polygon.radius();
            let circle_area = PI * circle_radius.powi(2);
            //pringing out the results
            println!(
                "Polygon's number of sides: {}, side length : {}, Polygon's Area: {}, circle's radius {}, Circle's area :{}",
                &num_sides, &side_length, polygon.area(), circle_radius, circle_area
            );
        }
    }
}