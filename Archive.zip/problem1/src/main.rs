use std::f64::consts::PI;

enum Shape {
    Triangle(f64, f64, f64),
    Rectangle(f64, f64),
    Circle(f64),
}
// implementing a function create instances of the type
impl Shape {
    fn new_triangle(a: f64, b: f64, c: f64) -> Shape {
        Shape::Triangle(a, b, c)
    }

    fn new_rectangle(length: f64, width: f64) -> Shape {
        Shape::Rectangle(length, width)
    }

    fn new_circle(radius: f64) -> Shape {
        Shape::Circle(radius)
    }

    // method for calculating the area of shape
    fn area(&self) -> f64 {
        match *self {
            Shape::Triangle(a, b, c) => {
                let s = (a + b + c) / 2.0;
                ((s * (s - a) * (s - b) * (s - c)) as f64).sqrt()
            },
            Shape::Rectangle(length, width) => length * width,
            Shape::Circle(radius) => PI * radius.powi(2),
        }
    }

    // method for calculating the perimeter of shape
    fn perimeter(&self) -> f64 {
        match *self {
            Shape::Triangle(a, b, c) => a + b + c,
            Shape::Rectangle(length, width) => 2.0 * (length + width),
            Shape::Circle(radius) => 2.0 * PI * radius,
        }
    }

    // method that doubles the perimeter of shape
    fn double_perimeter(&self) -> f64 {
        2.0 * self.perimeter()
    }

    // method for verifying the correctiveness of the parameters of shape
    fn verify(&self) -> bool {
        match *self {
            Shape::Triangle(a, b, c) => {
                a > 0.0 && b > 0.0 && c > 0.0 && a + b > c && a + c > b && b + c > a
            },
            Shape::Rectangle(length, width) => length > 0.0 && width > 0.0,
            Shape::Circle(radius) => radius > 0.0,
        }
    }
}

fn main() {
    let triangle = Shape::new_triangle(3.0, 4.0, 5.0);
    println!("TRIANGLE");
    println!("Area: {}, Perimeter: {}", triangle.area(), triangle.perimeter());
    println!("Double perimeter of triangle: {}", triangle.double_perimeter());
    println!("Parameters Correct: {}", triangle.verify());

    let rectangle = Shape::new_rectangle(4.0, 5.0);
    println!("RECTANGLE");
    println!("Area: {}, Perimeter: {}", rectangle.area(), rectangle.perimeter());
    println!("Double perimeter of rectangle: {}", rectangle.double_perimeter());
    println!("Parameters Correct: {}", rectangle.verify());

    let circle = Shape::new_circle(3.5);
    println!("CIRCLE");
    println!("Area: {}, Perimeter: {}", circle.area(), circle.perimeter());
    println!("Double perimeter of circle: {}", circle.double_perimeter());
    println!("Parameters Correct: {}", circle.verify());
}
